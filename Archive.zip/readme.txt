templates = controlpoints 
controlpoints = tagids 
only in front

in backend we have controlpoints with multiple tagids
in front we are showing template with multiple controlpoints, 
did'nt wnated to change schema