import Header from "./Header";
import Siderbar from "./Sidebar";
import Rightbar from "./Rightbar";
import Loader from "./Loader";

export { Header, Siderbar, Rightbar, Loader };
